package com.snhu.mobile2app;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class SMS extends Application {
    public static final String CHANNEL_ID_1 = "channel1";
    public static final String CHANNEL_ID_2 = "channel2";
    @Override
    public void onCreate() {
        super.onCreate();

        createNoticationChannels();
    }

    private void createNoticationChannels() {
        NotificationChannel channel1 = new NotificationChannel(
                CHANNEL_ID_1,
                "channel1",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel1.setDescription("This is channel 1");
        NotificationChannel channel2 = new NotificationChannel(
                CHANNEL_ID_2,
                "channel2",
                NotificationManager.IMPORTANCE_LOW
        );
        channel1.setDescription("This is channel 2");
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel1);
        manager.createNotificationChannel(channel2);
    }
}
