package com.snhu.mobile2app;

public class InventoryModel {
    private int id;
    private String itemName;
    private String itemQuantity;
    private String imgSrc;

    public String getImgSrc() {
        return imgSrc;
    }

    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "InventoryModel{" +
                "id=" + id +
                ", itemName='" + itemName + '\'' +
                ", itemQuantity='" + itemQuantity + '\'' +
                ", imgSrc='" + imgSrc + '\'' +
                '}';
    }

    public InventoryModel(int id, String itemName, String itemQuantity, String imgSrc) {
        this.id = id;
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
        this.imgSrc = imgSrc;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(String itemQuantity) {
        this.itemQuantity = itemQuantity;
    }
}
