package com.snhu.mobile2app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Inventory extends AppCompatActivity {
    Button btn, addItem, addQuantity, subQuantity;

    TextView userName;
    InventoryDatabaseHandler inventoryDatabaseHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        RecyclerView recyclerView = findViewById(R.id.inv_items);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager layoutManager = new GridLayoutManager(Inventory.this,2);
        recyclerView.setLayoutManager(layoutManager);
        inventoryDatabaseHandler = new InventoryDatabaseHandler(Inventory.this);


        RecyclerView.Adapter<MyAdapter.ViewHolder> mAdapter = new MyAdapter(inventoryDatabaseHandler.getItems(), Inventory.this);
        recyclerView.setAdapter(mAdapter);


        btn = findViewById(R.id.home);
        addItem = findViewById(R.id.add_inv_item);
       userName = findViewById(R.id.inv_user_name);
        Intent fetchData = getIntent();
       String greeting = "Welcome Back,\n" + fetchData.getStringExtra("user_name");
        userName.setText(greeting);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), LoginPage.class);
                startActivity(i);
            }
        });
        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inventoryDatabaseHandler.addItem(new InventoryModel(-1, "**Stock Name**", "1",
                        "https://imgs.search.brave.com/B3JN2hlDi7eLoW5_bxje87Y_L0loGMPRX4eBu6yzZWA" +
                                "/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9raW5z/dGEuY29tL3dwLWNv/bnRlbnQvdXBsb2Fk" +
                                "/cy8yMDE5LzA4L2pw/Zy12cy1qcGVnLTEw/MjR4NTEyLmpwZw"));
                Intent i = new Intent(getApplicationContext(), Inventory.class);
                i.putExtra("user_name",fetchData.getStringExtra("user_name"));
                startActivity(i);
                //userName.setText(greeting);
            }
        });

    }

}