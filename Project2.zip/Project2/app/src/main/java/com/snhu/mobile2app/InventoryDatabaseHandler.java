package com.snhu.mobile2app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class InventoryDatabaseHandler extends SQLiteOpenHelper {
    public static final String ID = "ID";
    public static final String IMG_COL = "IMG";
    public static final String ITEM_COL = "ITEM";
    public static final String QUANTITY_COL = "QUANTITY";
    public static final String TABLE_NAME = "INVENTORY_TABLE";

    private static final String DB = "inventory.db";
    public InventoryDatabaseHandler(Context context) {
        super(context, DB, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + IMG_COL + " TEXT,"
                + ITEM_COL + " TEXT,"
                + QUANTITY_COL + " TEXT)";
        db.execSQL(query);
    }

    public void addItem(InventoryModel item){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues val = new ContentValues();
        val.put(IMG_COL,item.getImgSrc());
        val.put(ITEM_COL, item.getItemName());
        val.put(QUANTITY_COL, item.getItemQuantity());
        db.insert(TABLE_NAME, null, val);
    }

    public List<InventoryModel> getItems(){
        List<InventoryModel> items = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()){
            do{
                int itemID = cursor.getInt(0);
                String imgSrc = cursor.getString(1);
                String itemName = cursor.getString(2);
                String itemQuantity = cursor.getString(3);

                InventoryModel item = new InventoryModel(itemID, itemName, itemQuantity, imgSrc);
                items.add(item);
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return items;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
