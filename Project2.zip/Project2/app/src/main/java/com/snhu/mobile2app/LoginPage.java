package com.snhu.mobile2app;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class LoginPage extends AppCompatActivity {
    Button btn, newUserBtn;
    EditText userName, password;
    LoginDataBaseHandler dbh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        btn = findViewById(R.id.nextPage);
        userName = findViewById(R.id.user_name);
        password = findViewById(R.id.password);
        newUserBtn = findViewById(R.id.new_login);



        btn.setOnClickListener(v -> {
            List<LoginModel> getUsers;

            dbh = new LoginDataBaseHandler(LoginPage.this);
            getUsers = dbh.getUsers();
            for (int i = 0; i < getUsers.size(); i++) {
                if (getUsers.get(i).getUserName().equals(userName.getText().toString()) &&
                        getUsers.get(i).getPassword().equals(password.getText().toString())) {
                    Intent intent = new Intent(getApplicationContext(), Inventory.class);
                    intent.putExtra("user_name",userName.getText().toString());
                    startActivity(intent);
                    return;
                }
                if (i == getUsers.size() - 1)
                    Toast.makeText(LoginPage.this, "Wrong username/password given...", Toast.LENGTH_LONG).show();
            }


        });
        newUserBtn.setOnClickListener(v -> {

                Intent intent = new Intent(getApplicationContext(), NewLogin.class);
                startActivity(intent);
            });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.test_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.item1) {
            Intent intent = new Intent(LoginPage.this, SettingsActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }



}