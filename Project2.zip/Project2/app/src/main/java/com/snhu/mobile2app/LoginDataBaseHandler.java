package com.snhu.mobile2app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class LoginDataBaseHandler extends SQLiteOpenHelper {
    private static final String ID = "ID";
    private static final String USER_NAME_COL = "USER_NAME";
    private static final String PASSWORD_COL = "PASSWORD";
    private static final String DB = "login.db";
    private static final String TABLE_NAME = "LOGIN_TABLE";
    public LoginDataBaseHandler(Context context){
        super(context,DB, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_NAME_COL + " TEXT,"
                + PASSWORD_COL + " TEXT)";

        db.execSQL(query);
    }
    public void addUser(LoginModel user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues val = new ContentValues();
        val.put(USER_NAME_COL, user.getUserName());
        val.put(PASSWORD_COL, user.getPassword());
        db.insert(TABLE_NAME, null, val);
    }

    public List<LoginModel> getUsers(){
        List<LoginModel> users = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query,null);

        if(cursor.moveToFirst()){
            do {
                int userID = cursor.getInt(0);
                String userName = cursor.getString(1);
                String password = cursor.getString(2);

                LoginModel user = new LoginModel(userID, userName, password);
                users.add(user);

            }
                while (cursor.moveToNext());

        }
        else {

        }
        cursor.close();
        db.close();
        return users;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
