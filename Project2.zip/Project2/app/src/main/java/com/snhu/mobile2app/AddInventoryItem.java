package com.snhu.mobile2app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddInventoryItem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_inventory_item);
    }
}