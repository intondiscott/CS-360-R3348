package com.snhu.mobile2app;

import static com.snhu.mobile2app.SMS.CHANNEL_ID_1;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.Manifest;
import android.app.Notification;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewLogin extends AppCompatActivity {
    EditText userName, password;
LoginModel user;
    LoginDataBaseHandler dbh;
    Button createAccount;

    NotificationManagerCompat notificationManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_login);
        userName = findViewById(R.id.new_user_name);
        password = findViewById(R.id.new_password);
        createAccount = findViewById(R.id.create_account);
        notificationManager = NotificationManagerCompat.from(this);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
            @Override
            public void onClick(View v) {
                user = new LoginModel(-1, userName.getText().toString(), password.getText().toString());
               dbh = new LoginDataBaseHandler(NewLogin.this);
               dbh.addUser(user);

               Intent i = new Intent(getApplicationContext(), LoginPage.class);
                Notification notification = new NotificationCompat.Builder(NewLogin.this, CHANNEL_ID_1)
                        .setSmallIcon(R.drawable.ic_setting)
                        .setContentTitle("New User Added:")
                        .setContentText(userName.getText() + " was added to database")
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                        .build();
                startActivity(i);
                if (ActivityCompat.checkSelfPermission(NewLogin.this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {

                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    //Toast.makeText(this,"help", Toast.LENGTH_LONG).show();
                    requestPermissions(
                            new String[] {Manifest.permission.POST_NOTIFICATIONS},
                            1);
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                     return;


                }

                notificationManager.notify(1, notification);

            }
        });


    }
}