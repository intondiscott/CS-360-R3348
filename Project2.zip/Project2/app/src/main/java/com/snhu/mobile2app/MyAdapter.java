package com.snhu.mobile2app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    List<InventoryModel> getItems;
    Context context;

    public MyAdapter(List<InventoryModel> getItems, Context context) {
        this.getItems = getItems;
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_item,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {

        holder.tv_item.setText(getItems.get(position).getItemName());
        holder.tv_quantity.setText((getItems.get(position).getItemQuantity()));
        Glide.with(this.context).load(getItems.get(position).getImgSrc()).into(holder.iv_item);
    }

    @Override
    public int getItemCount() {
        return getItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_item;
        TextView tv_item, tv_quantity;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_item = itemView.findViewById(R.id.iv_inventory_item);
            tv_item = itemView.findViewById(R.id.tv_inventory_item);
            tv_quantity = itemView.findViewById(R.id.tv_inventory_quantity);
        }
    }
}
